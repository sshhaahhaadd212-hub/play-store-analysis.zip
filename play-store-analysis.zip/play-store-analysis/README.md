# Google Play Store Apps Analysis

Lab mini project for 2323 CIS - Introduction to Data Science, King Khalid University.

## Objective

In this project we analyze data about more than 9,000 apps on the Google Play Store to answer this question:

> How are the app category, the price type (free or paid) and the sentiment of user reviews related to the popularity and rating of apps on Google Play?

The goal is to give a new app developer simple, data-based guidance on choosing a category and deciding whether the app should be free or paid.

## Dataset

- **Name:** Google Play Store Apps
- **Author:** Lavanya Gupta (Kaggle)
- **Link:** https://www.kaggle.com/datasets/lava18/google-play-store-apps
- **License:** Creative Commons Attribution 3.0 (CC BY 3.0)
- **Files:** `googleplaystore.csv` (10,841 rows, 13 columns) and `googleplaystore_user_reviews.csv` (64,295 rows, 5 columns)

The files and their columns are described in [data/README.md](data/README.md).

## Project Structure

```
play-store-analysis/
├── README.md
├── .gitignore
├── notebooks/
│   └── analysis.ipynb
├── data/
│   ├── README.md
│   ├── raw/
│   │   ├── googleplaystore.csv
│   │   ├── googleplaystore_user_reviews.csv
│   │   └── license.txt
│   └── clean/
│       ├── apps_clean.csv
│       └── apps_reviews.csv
└── outputs/
    └── figures/
        ├── top_categories.png
        ├── free_vs_paid.png
        └── reviews_by_rating.png
```

## Steps

1. **Data understanding:** checked the shape, columns, data types, missing values and basic statistics of both files, and listed the data quality problems.
2. **Cleaning:** removed one broken row, exact duplicates, older records of the same app, empty reviews and repeated reviews. We filled the one missing app type from the price, and kept the apps without a rating with an empty rating.
3. **Transformation:** converted reviews, installs, price and size to numbers, used regular expressions to extract the size unit and the minimum Android version, converted the update date to a date type and added new columns.
4. **Aggregation and merging:** summarized the reviews for each app, merged them with the apps data, and grouped the apps by category and by price type.
5. **Analysis and visualization:** answered the three parts of the question with tables and three charts, each with a written interpretation.

## Results

**1. Game, Communication and Tools get the most installs**, with 43.3% of all installs together. Family has the most apps but comes fourth.

![Top 10 categories by total installs](outputs/figures/top_categories.png)

**2. Free apps get far more installs than paid apps** (median 100,000 vs 1,000), while paid apps have a slightly higher median rating (4.4 vs 4.3).

![Free vs paid apps](outputs/figures/free_vs_paid.png)

**3. Higher rated apps get more positive reviews.** The share of positive reviews rises from 47.6% for apps rated 3.5 or less to 72.1% for apps rated 4.6 to 5.0 (correlation 0.32).

![Share of positive reviews by app rating](outputs/figures/reviews_by_rating.png)

**Limitations:** the data was collected in 2018, installs are given as ranges (we used the lower limit), and the reviews file covers only 816 of the 9,659 apps.

## How to Run

**Google Colab**

1. Open Google Colab and upload `notebooks/analysis.ipynb` (File > Upload notebook).
2. Choose Runtime > Run all.
3. When the notebook asks for the data, upload the two CSV files from `data/raw`.

**Jupyter Notebook**

1. Download or clone this repository.
2. Open `notebooks/analysis.ipynb`.
3. Restart the kernel and run all cells.

The notebook needs Python 3 with pandas, NumPy and Matplotlib. It saves the clean data to `data/clean` and the charts to `outputs/figures`.

## Team Contributions

| Member | Contribution |
|---|---|
| | Topic selection, data question and objective, finding and downloading the dataset, documenting the data source |
| | Setting up the environment, loading the data, and data understanding (shape, columns, types, missing values) |
| | Data cleaning and error handling |
| | Data transformation, aggregation, merging and saving the final dataset |
| | Data analysis, visualizations and their interpretations |

All members worked together on the results and conclusions, the README, the GitHub repository, reviewing each other's sections and the presentation.
