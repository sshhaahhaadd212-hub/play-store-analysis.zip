# Data

## Source

- **Dataset:** Google Play Store Apps
- **Author:** Lavanya Gupta
- **Link:** https://www.kaggle.com/datasets/lava18/google-play-store-apps
- **License:** Creative Commons Attribution 3.0 (see `raw/license.txt`)
- **Collected:** from the Google Play Store website in 2018
- **Downloaded:** November 2026, without any changes

## Raw Files (`raw/`)

### googleplaystore.csv

10,841 rows and 13 columns. Each row is one app.

| Column | Description |
|---|---|
| App | App name |
| Category | Category of the app |
| Rating | Average user rating (1 to 5) |
| Reviews | Number of user reviews |
| Size | App size, for example `19M`, `201k` or `Varies with device` |
| Installs | Number of installs as a range, for example `10,000+` |
| Type | Free or Paid |
| Price | Price in US dollars |
| Content Rating | Age group, for example Everyone or Teen |
| Genres | One or more genres separated by `;` |
| Last Updated | Date of the last update |
| Current Ver | Current version of the app |
| Android Ver | Minimum Android version needed |

### googleplaystore_user_reviews.csv

64,295 rows and 5 columns. Each row is one user review.

| Column | Description |
|---|---|
| App | App name |
| Translated_Review | Review text in English |
| Sentiment | Positive, Negative or Neutral |
| Sentiment_Polarity | Score from -1 (negative) to 1 (positive) |
| Sentiment_Subjectivity | Score from 0 (objective) to 1 (subjective) |

## Clean Files (`clean/`)

Both files are created by `notebooks/analysis.ipynb`. Column names are in lowercase with underscores.

### apps_clean.csv

9,659 rows (one row per app) and 17 columns. It has the original columns after cleaning, with `reviews`, `installs` and `price` as numbers and `last_updated` as a date, plus these new columns:

| Column | Description |
|---|---|
| size_mb | App size in megabytes (empty for `Varies with device`) |
| update_year | Year of the last update |
| main_genre | First genre in `genres` |
| min_android | Minimum Android version as a number, for example 4.1 |

### apps_reviews.csv

816 rows and 20 columns. These are the apps that have reviews, with the columns of `apps_clean.csv` plus:

| Column | Description |
|---|---|
| review_count | Number of reviews for the app after cleaning |
| positive_share | Share of positive reviews (0 to 1) |
| avg_polarity | Average sentiment polarity of the reviews |
